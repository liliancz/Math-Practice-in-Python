from app_class import *

if __name__== '__main__':
    app = App()
    app.run()

